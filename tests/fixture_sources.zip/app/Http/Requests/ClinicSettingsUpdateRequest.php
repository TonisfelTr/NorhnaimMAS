<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ClinicSettingsUpdateRequest extends FormRequest
{
    public function authorize(): bool
    {
        $doctor = auth()->user()->doctor;
        return is_authed() && $doctor->clinic->headmaster_id == $doctor->id ;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            // clinic-benefit-requisites:rules:v1:begin
            'benefit_clinic' => [
                'sometimes',
                'array:prescribing_enabled,kind,ogrn,code,series,numbering_source,license_number,license_date,license_authority',
                'required_array_keys:prescribing_enabled,kind',
            ],
            'benefit_clinic.prescribing_enabled' => [
                'bail',
                'required_with:benefit_clinic',
                'boolean',
            ],
            'benefit_clinic.kind' => [
                'bail',
                'required_with:benefit_clinic',
                'string',
                Rule::in(['organization', 'individual']),
            ],
            'benefit_clinic.ogrn' => [
                'bail',
                'nullable',
                'string',
                $this->input('benefit_clinic.kind') === 'individual'
                    ? 'regex:/\A[0-9]{15}\z/'
                    : 'regex:/\A[0-9]{13}\z/',
            ],
            'benefit_clinic.code' => ['bail', 'nullable', 'string', 'max:50'],
            'benefit_clinic.series' => [
                'bail',
                'nullable',
                'string',
                'max:20',
                'regex:/\A[0-9]{2}[0-9A-ZА-ЯЁ\/-]*\z/iu',
            ],
            'benefit_clinic.numbering_source' => ['bail', 'nullable', 'string', 'max:1000'],
            'benefit_clinic.license_number' => ['bail', 'nullable', 'string', 'max:100'],
            'benefit_clinic.license_date' => ['bail', 'nullable', 'string', 'date_format:Y-m-d'],
            'benefit_clinic.license_authority' => ['bail', 'nullable', 'string', 'max:500'],
            // clinic-benefit-requisites:rules:v1:end
            // clinic-benefit-okato:rules:v1:begin
            'benefit_okato_prefix' => [
                'bail',
                'sometimes',
                'nullable',
                'string',
                'regex:/\A[0-9]{2}\z/',
            ],
            // clinic-benefit-okato:rules:v1:end
            'description' => 'nullable|string|max:10000',

            'address' => 'required|string|max:500',
            'address_confirmed' => 'required|accepted',
            'city' => 'nullable|string|max:150',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',

            'phones' => 'required|array|min:1|max:20',
            'phones.*.phone' => 'required|string|max:32',
            'phones.*.label' => 'nullable|string|max:120',

            'services' => 'required|array|min:1',
            'services.*' => [
                'required',
                'string',
                'distinct',
                Rule::in([
                    'in_person',
                    'telemedicine',
                ]),
            ],

            'working_hours' => 'required|array',
            'working_hours.mon' => 'required|array',
            'working_hours.tue' => 'required|array',
            'working_hours.wed' => 'required|array',
            'working_hours.thu' => 'required|array',
            'working_hours.fri' => 'required|array',
            'working_hours.sat' => 'required|array',
            'working_hours.sun' => 'required|array',

            'working_hours.*.enabled' => 'required|boolean',
            'working_hours.*.from' => 'nullable|date_format:H:i',
            'working_hours.*.to' => 'nullable|date_format:H:i',

            'employees' => 'nullable|array|max:500',
            'employees.*.id' => 'nullable|integer',
            'employees.*.surname' => 'required|string|max:100',
            'employees.*.name' => 'required|string|max:100',
            'employees.*.patronym' => 'nullable|string|max:100',
            'employees.*.position' => 'required|string|max:150',

            'employees.*.specialties' => 'nullable|array|max:20',
            'employees.*.specialties.*' => 'required|string|max:150',

            'employees.*.employment_status' => [
                'required',
                Rule::in([
                    'active',
                    'temporarily_absent',
                    'inactive',
                ]),
            ],

            'employees.*.phone' => 'nullable|string|max:32',
            'employees.*.email' => 'nullable|email|max:255',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Укажите название клиники.',
            // clinic-benefit-requisites:messages:v1:begin
            'benefit_clinic.array' => 'Проверьте поля реквизитов для льготных рецептов.',
            'benefit_clinic.required_array_keys' => 'Укажите юридический статус и настройку оформления льготных рецептов.',
            'benefit_clinic.prescribing_enabled.required_with' => 'Укажите, включено ли оформление льготных рецептов.',
            'benefit_clinic.prescribing_enabled.boolean' => 'Выберите, включено ли оформление льготных рецептов.',
            'benefit_clinic.kind.required_with' => 'Выберите юридический статус клиники.',
            'benefit_clinic.kind.string' => 'Выберите юридический статус клиники из списка.',
            'benefit_clinic.kind.in' => 'Выберите юридическое лицо или индивидуального предпринимателя.',
            'benefit_clinic.ogrn.string' => 'Введите ОГРН или ОГРНИП цифрами без пробелов.',
            'benefit_clinic.ogrn.regex' => 'ОГРН юридического лица должен содержать 13 цифр, ОГРНИП — 15 цифр.',
            'benefit_clinic.code.string' => 'Введите код организации текстом.',
            'benefit_clinic.code.max' => 'Код организации не должен превышать 50 символов.',
            'benefit_clinic.series.string' => 'Введите серию рецептов текстом.',
            'benefit_clinic.series.max' => 'Серия рецептов не должна превышать 20 символов.',
            'benefit_clinic.series.regex' => 'Серия начинается с двух цифр; далее допустимы цифры, русские и латинские буквы, дефис и косая черта.',
            'benefit_clinic.numbering_source.string' => 'Укажите источник нумерации текстом.',
            'benefit_clinic.numbering_source.max' => 'Источник нумерации не должен превышать 1000 символов.',
            'benefit_clinic.license_number.string' => 'Введите номер лицензии текстом.',
            'benefit_clinic.license_number.max' => 'Номер лицензии не должен превышать 100 символов.',
            'benefit_clinic.license_date.string' => 'Укажите дату выдачи лицензии в формате ГГГГ-ММ-ДД.',
            'benefit_clinic.license_date.date_format' => 'Укажите существующую дату выдачи лицензии в формате ГГГГ-ММ-ДД.',
            'benefit_clinic.license_authority.string' => 'Укажите название лицензирующего органа текстом.',
            'benefit_clinic.license_authority.max' => 'Название лицензирующего органа не должно превышать 500 символов.',
            // clinic-benefit-requisites:messages:v1:end
            // clinic-benefit-okato:messages:v1:begin
            'benefit_okato_prefix.string' => 'Укажите первые две цифры ОКАТО.',
            'benefit_okato_prefix.regex' => 'Укажите ровно две цифры ОКАТО от 0 до 9 или оставьте поле пустым.',
            // clinic-benefit-okato:messages:v1:end

            'address.required' => 'Укажите адрес клиники.',
            'address_confirmed.accepted' => 'Выберите адрес из предложенного списка.',

            'phones.required' => 'Укажите хотя бы один телефон регистратуры.',
            'phones.min' => 'Укажите хотя бы один телефон регистратуры.',
            'phones.*.phone.required' => 'Укажите номер телефона.',

            'services.required' => 'Выберите хотя бы один формат оказания медицинской помощи.',
            'services.min' => 'Выберите хотя бы один формат оказания медицинской помощи.',

            'employees.*.surname.required' => 'Укажите фамилию сотрудника.',
            'employees.*.name.required' => 'Укажите имя сотрудника.',
            'employees.*.position.required' => 'Укажите должность сотрудника.',
            'employees.*.email.email' => 'Укажите корректный e-mail сотрудника.',
        ];
    }

    protected function prepareForValidation(): void
    {
        $workingHours = $this->input('working_hours', []);

        if (is_array($workingHours)) {
            foreach ($workingHours as $day => $hours) {
                if (!is_array($hours)) {
                    continue;
                }

                $workingHours[$day]['enabled'] = filter_var(
                    $hours['enabled'] ?? false,
                    FILTER_VALIDATE_BOOLEAN
                );
            }
        }

        $this->merge([
            'address_confirmed' => $this->boolean('address_confirmed'),
            'working_hours' => $workingHours,
        ]);
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator): void {
            $workingHours = $this->input('working_hours', []);

            if (!is_array($workingHours)) {
                return;
            }

            $hasWorkingDay = false;

            foreach ([
                         'mon',
                         'tue',
                         'wed',
                         'thu',
                         'fri',
                         'sat',
                         'sun',
                     ] as $day) {
                $hours = $workingHours[$day] ?? [];

                if (empty($hours['enabled'])) {
                    continue;
                }

                $hasWorkingDay = true;

                $from = $hours['from'] ?? null;
                $to = $hours['to'] ?? null;

                if (!$from) {
                    $validator->errors()->add(
                        "working_hours.{$day}.from",
                        'Укажите время начала работы.'
                    );
                }

                if (!$to) {
                    $validator->errors()->add(
                        "working_hours.{$day}.to",
                        'Укажите время окончания работы.'
                    );
                }

                if ($from && $to && $from >= $to) {
                    $validator->errors()->add(
                        "working_hours.{$day}.to",
                        'Время окончания работы должно быть позже времени начала.'
                    );
                }
            }

            if (!$hasWorkingDay) {
                $validator->errors()->add(
                    'working_hours',
                    'Укажите хотя бы один рабочий день клиники.'
                );
            }
        });
    }
}
