<?php

namespace App\Services;

use App\Http\Controllers\Doctors\ReceptionController;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\RegistryRecord;
use App\Support\HospitalPatientAccess;
use App\Support\TelemedicineJournalRules;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/** Manages the appointments displayed in the existing telemedicine journal. */
class TelemedicineJournalService
{
    private const CLINICAL_FIELDS = [
        'complaints', 'disease_history', 'life_history', 'social_history',
        'mental_status', 'diagnosis_code', 'diagnosis_title', 'conclusion',
        'recommendations', 'service_code', 'service_name',
    ];
    private const CONNECTION_EVENTS = [
        'participant_joined', 'participant_left', 'media_connected',
        'connection_failed', 'call_ended',
    ];

    public function __construct(
        private HospitalPatientAccess $access,
        private MedicalVisitAuditService $audit
    ) {}

    public function ready(): bool
    {
        foreach (['registry_records', 'medical_visit_events', 'medical_visit_confirmations'] as $table) {
            if (!Schema::hasTable($table)) return false;
        }
        return Schema::hasColumn('registry_records', 'appointment_format')
            && Schema::hasColumn('registry_records', 'deleted_at');
    }

    public function canManage($user, Patient $patient): bool
    {
        // NORHNAIM_TELEMED_ACCESS_V1: separate scheduling permission, not clinical editing.
        return app(\App\Support\TelemedicineJournalAccess::class)->canManage($user, $patient);
    }

    public function journalAppointments($user, Patient $patient): \Illuminate\Database\Eloquent\Builder
    {
        $policy = app(\App\Support\TelemedicineJournalAccess::class);
        if ($policy->canManage($user, $patient)) {
            return $policy->manageableAppointments($user, $patient);
        }
        return $this->audit->visibleAppointments($user, $patient, $this->access);
    }


    public function authorize($user, Patient $patient): void
    {
        abort_unless($this->canManage($user, $patient), 403,
            app(\App\Support\TelemedicineJournalAccess::class)->explain($user, $patient)['reason']);
        abort_unless($this->ready(), 503, 'Не установлены таблицы журнала телемедицины.');
    }

    /** A patient in private practice is not grouped with unrelated private doctors. */
    private function doctorQuery(Patient $patient)
    {
        $patient->loadMissing('doctor');
        $assigned = $patient->doctor;
        $query = Doctor::query()->with('clinic');
        if (!$assigned) return $query->whereRaw('1 = 0');
        $clinicId = (int) ($assigned->clinic_id ?? 0);
        $patientClinicId = (int) ($patient->getAttribute('clinic_id') ?? 0);
        if ($patientClinicId > 0 && $patientClinicId !== $clinicId) {
            return $query->whereRaw('1 = 0');
        }
        return $clinicId > 0
            ? $query->where('clinic_id', $clinicId)
            : $query->whereKey($assigned->getKey());
    }

    private function doctorName(Doctor $doctor): string
    {
        return trim(implode(' ', array_filter([
            $doctor->surname, $doctor->name, $doctor->patronym,
        ]))) ?: 'Врач #' . $doctor->getKey();
    }

    /** Additional data for Blade. No database queries or authorization in templates. */
    public function decorate(Request $request, Patient $patient, array $auditContext): array
    {
        $ready = $this->ready();
        $canManage = $ready && $this->canManage($request->user(), $patient);
        $doctors = $canManage
            ? $this->doctorQuery($patient)->orderBy('surname')->orderBy('name')->get()
            : collect();
        $selected = (int) $request->old('telemed_doctor_id', $patient->doctor_id);
        $defaultDate = now()->addMinutes(30)->startOfMinute()->format('Y-m-d\TH:i');
        $query = $request->query();
        unset($query['telemed_page'], $query['telemed_open']);
        $query['tab'] = 'telemedicine-log';
        $activeUrl = $request->url() . '?' . http_build_query(array_merge($query, ['telemed_archive' => 0]));
        $archiveUrl = $request->url() . '?' . http_build_query(array_merge($query, ['telemed_archive' => 1]));
        $auditContext['telemedManager'] = [
            'ready' => $ready,
            'can_create' => $canManage && $doctors->isNotEmpty(),
            'disabled_reason' => !$ready ? 'Сначала установите таблицы журнала.'
                : (!$canManage ? app(\App\Support\TelemedicineJournalAccess::class)->explain($request->user(), $patient)['reason']
                    : ($doctors->isEmpty() ? 'У пациента не определён лечащий врач или клиника.' : '')),
            'doctors' => $doctors->map(fn (Doctor $doctor) => [
                'id' => (int) $doctor->getKey(), 'name' => $this->doctorName($doctor),
                'selected' => (int) $doctor->getKey() === $selected,
            ])->all(),
            'create_url' => route('doctors.patients.telemedicine-journal.store', $patient),
            'starts_at' => $request->old('telemed_starts_at', $defaultDate),
            'minimum' => now()->startOfMinute()->format('Y-m-d\TH:i'),
            'timezone' => (string) config('app.timezone', 'UTC'),
            'request_id' => $request->old('telemed_request_id', (string) Str::uuid()),
            'create_errors' => $request->session()->get('errors')?->getBag('telemedCreate')->all() ?? [],
            'delete_errors' => $request->session()->get('errors')?->getBag('telemedDelete')->all() ?? [],
            'success' => $request->session()->get('telemed_journal_success'),
            'active_url' => $activeUrl, 'archive_url' => $archiveUrl,
            'show_archive' => $request->boolean('telemed_archive'),
        ];
        $log = $auditContext['telemedicineLog'] ?? null;
        if (!$ready || !$log || $log->getCollection()->isEmpty()) return $auditContext;

        $ids = $log->getCollection()->pluck('id')->all();
        // Reuse the established appointment visibility scope, including for writes.
        $records = $this->journalAppointments($request->user(), $patient)
            ->whereKey($ids)->get()->keyBy('id');
        $snapshots = $this->snapshots($ids);
        $log->setCollection($log->getCollection()->map(function (array $call) use (
            $records, $snapshots, $canManage, $patient
        ): array {
            $record = $records->get($call['id']);
            if (!$record) {
                $call['journal'] = ['can_delete' => false, 'label' => 'Недоступен',
                    'state' => 'unknown', 'reason' => 'Нет доступа к записи.', 'delete_url' => null];
                return $call;
            }
            $call['journal'] = $this->decision($record, $snapshots, $canManage);
            $call['journal']['delete_url'] = route('doctors.patients.telemedicine-journal.destroy', [
                'patient' => $patient->getKey(), 'registryRecord' => $record->getKey(),
            ]);
            return $call;
        }));
        return $auditContext;
    }

    private function snapshots(array $ids, bool $lock = false): array
    {
        $confirm = DB::table('medical_visit_confirmations')->whereIn('registry_record_id', $ids);
        $encounters = Schema::hasTable('medical_encounters')
            ? DB::table('medical_encounters')->whereIn('registry_record_id', $ids) : null;
        if ($lock) {
            $confirm->lockForUpdate();
            $encounters?->lockForUpdate();
        }
        return [
            'confirmations' => $confirm->get()->keyBy('registry_record_id'),
            'encounters' => $encounters?->get()->groupBy('registry_record_id') ?? collect(),
            'events' => DB::table('medical_visit_events')->whereIn('registry_record_id', $ids)
                ->where('source', 'signaling')->whereIn('event_type', self::CONNECTION_EVENTS)
                ->orderBy('occurred_at')->orderBy('id')
                ->get(['registry_record_id', 'room_id', 'event_type', 'participant_role'])
                ->groupBy('registry_record_id'),
        ];
    }

    private function decision(RegistryRecord $record, array $snapshots, bool $canManage): array
    {
        $id = (int) $record->getKey();
        $confirmation = $snapshots['confirmations']->get($id)?->outcome;
        $encounters = $snapshots['encounters']->get($id, collect());
        $consultation = null;
        $document = false;
        foreach ($encounters as $encounter) {
            $attributes = (array) $encounter;
            $status = $attributes['consultation_status'] ?? null;
            // Multiple unexpected clinical rows must not hide a completed record.
            if ($status === 'completed') $document = true;
            if ($status === 'in_progress' || $consultation !== 'in_progress') $consultation = $status;
            foreach (self::CLINICAL_FIELDS as $field) {
                if (isset($attributes[$field]) && trim((string) $attributes[$field]) !== '') $document = true;
            }
            foreach (['signed_at', 'finalized_at', 'completed_at'] as $field) {
                if (!empty($attributes[$field])) $document = true;
            }
        }
        $raw = $record->getRawOriginal('for_datetime') ?: $record->for_datetime;
        try { $start = $raw ? Carbon::parse($raw) : null; } catch (\Throwable) { $start = null; }
        return TelemedicineJournalRules::deletion(
            $canManage, $record->deleted_at !== null, $start, $confirmation,
            $consultation, $document,
            TelemedicineJournalRules::hasOpenConnection($snapshots['events']->get($id, collect())), now()
        );
    }

    public function create($user, Patient $patient, array $data): RegistryRecord
    {
        $this->authorize($user, $patient);
        $start = Carbon::createFromFormat('!Y-m-d\TH:i', $data['telemed_starts_at'], config('app.timezone'));
        $eventUid = 'tm-schedule-' . strtolower($data['telemed_request_id']);
        return DB::transaction(function () use ($user, $patient, $data, $start, $eventUid) {
            $lockedPatient = Patient::query()->whereKey($patient->getKey())->lockForUpdate()->firstOrFail();
            $this->authorize($user, $lockedPatient);
            $previous = DB::table('medical_visit_events')->where('event_uid', $eventUid)->first();
            if ($previous) {
                $meta = json_decode((string) $previous->details, true) ?: [];
                abort_unless((int) $previous->patient_id === (int) $patient->getKey()
                    && (int) $previous->actor_user_id === (int) $user->getKey()
                    && $previous->event_type === 'session_scheduled'
                    && (int) ($meta['doctor_id'] ?? 0) === (int) $data['telemed_doctor_id']
                    && ($meta['starts_at'] ?? null) === $start->format('Y-m-d H:i:s'), 409,
                    'Этот запрос уже использован с другими параметрами. Обновите страницу.');
                return $this->journalAppointments($user, $lockedPatient)
                    ->whereKey($previous->registry_record_id)->firstOrFail();
            }
            if (!$start->isFuture()) $this->invalid('Укажите дату и время позже текущего момента.', 'telemed_starts_at');
            $doctor = $this->doctorQuery($lockedPatient)->whereKey($data['telemed_doctor_id'])
                ->lockForUpdate()->first();
            if (!$doctor) $this->invalid('Выбранный врач недоступен в клинике пациента.', 'telemed_doctor_id');
            // Do not modify patient.doctor_id; the chosen doctor belongs to this appointment only.
            app(ReceptionController::class)->validateAppointmentWithinClinicSchedule($doctor, $start, appointmentFormat: 'telemedicine');
            $conflict = RegistryRecord::query()->whereNull('deleted_at')->where('for_datetime', $start)
                ->where(function ($q) use ($doctor, $lockedPatient) {
                    $q->where('doctor_id', $doctor->getKey())->orWhere('patient_id', $lockedPatient->getKey());
                })->exists();
            if ($conflict) $this->invalid('На это время уже есть запись у врача или пациента.', 'telemed_starts_at');
            $record = new RegistryRecord();
            $record->patient_id = $lockedPatient->getKey();
            $record->doctor_id = $doctor->getKey();
            $record->clinic_id = $doctor->clinic_id;
            $record->for_datetime = $start;
            $record->appointment_format = 'telemedicine';
            $record->appointment = false;
            $record->save();
            $this->audit->appendEvent((int) $record->getKey(), (int) $lockedPatient->getKey(),
                'session_scheduled', 'staff', 'system', (int) $user->getKey(), null,
                ['doctor_id' => (int) $doctor->getKey(), 'starts_at' => $start->format('Y-m-d H:i:s')],
                now(), $eventUid);
            return $record;
        }, 3);
    }

    public function cancel($user, Patient $patient, int $appointmentId, string $reason): void
    {
        $this->authorize($user, $patient);
        DB::transaction(function () use ($user, $patient, $appointmentId, $reason): void {
            // Lock current assignment before selecting a cancellable appointment.
            $freshPatient = Patient::query()->whereKey($patient->getKey())->lockForUpdate()->firstOrFail();
            $this->authorize($user, $freshPatient);
            $record = $this->journalAppointments($user, $freshPatient)
                ->whereKey($appointmentId)->where('appointment_format', 'telemedicine')
                ->lockForUpdate()->firstOrFail();
            if ($record->deleted_at !== null) return; // Idempotent repeated DELETE.
            $decision = $this->decision($record, $this->snapshots([$appointmentId], true), true);
            if (!$decision['can_delete']) $this->invalid($decision['reason'], 'telemed_delete_reason', 'telemedDelete');
            // Explicit soft cancellation. Never forceDelete or delete clinical/audit rows.
            DB::table('registry_records')->where('id', $appointmentId)->whereNull('deleted_at')->update([
                'deleted_at' => now(), 'updated_at' => now(),
            ]);
            $this->audit->appendEvent($appointmentId, (int) $patient->getKey(),
                'session_cancelled', 'staff', 'system', (int) $user->getKey(), null,
                ['reason' => $reason, 'previous_state' => $decision['state']], now());
        }, 3);
    }

    private function invalid(string $message, string $field, string $bag = 'telemedCreate'): never
    {
        throw ValidationException::withMessages([$field => $message])->errorBag($bag);
    }
}
