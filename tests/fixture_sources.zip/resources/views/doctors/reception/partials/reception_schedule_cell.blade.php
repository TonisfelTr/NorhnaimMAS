@if(isset($receptionRow['schedule']))
    <div class="d-flex flex-column gap-1 align-items-start">
        @if($receptionRow['schedule']['iso'])
            <time datetime="{{ $receptionRow['schedule']['iso'] }}" class="text-nowrap">
                <span class="fw-bold fs-5">{{ $receptionRow['schedule']['time'] }}</span>
                <span class="ms-1">{{ $receptionRow['schedule']['date'] }}</span>
            </time>
            @if($receptionRow['schedule']['relative_day'])
                <span class="small text-muted">{{ $receptionRow['schedule']['relative_day'] }}</span>
            @endif
        @else
            <span class="text-muted">Дата и время не указаны</span>
        @endif
        <span class="small text-nowrap">
            <i class="bi {{ $receptionRow['schedule']['format_icon'] }} me-1" aria-hidden="true"></i>
            {{ $receptionRow['schedule']['format_label'] }}
        </span>
        <span class="badge rounded-pill {{ $receptionRow['schedule']['state_class'] }}">
            {{ $receptionRow['schedule']['state_label'] }}
        </span>
        @if($receptionRow['schedule']['appointment_doctor'])
            <span class="small">Принимает: {{ $receptionRow['schedule']['appointment_doctor'] }}</span>
        @endif
        @if($receptionRow['schedule']['journal_url'])
            <a class="small mt-1" href="{{ $receptionRow['schedule']['journal_url'] }}">Журнал телемедицины</a>
        @endif
    </div>
@else
    <span class="text-muted">—</span>
@endif
